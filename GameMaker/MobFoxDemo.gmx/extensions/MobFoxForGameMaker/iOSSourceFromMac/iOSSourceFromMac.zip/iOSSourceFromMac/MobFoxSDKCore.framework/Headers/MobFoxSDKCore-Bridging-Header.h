//
//  -Bridging-Header.h
//  MobFoxSDKCore
//
//  Created by Shimi Sheetrit on 2/16/16.
//  Copyright © 2016 Itamar Nabriski. All rights reserved.
//

#ifndef _Bridging_Header_h
#define _Bridging_Header_h

#import "MobFoxAd.h"
#import "MobFoxInterstitialAd.h"
#import "MobFoxNativeAd.h"
#import "MobFoxCustomEvent.h"
#import "MobFoxInterstitialCustomEvent.h"
#import "MobFoxNativeCustomEvent.h"



#endif /* _Bridging_Header_h */
